# 26. Fast Fibonacci — Matrix Exponentiation

Calculates `F(n)` in `O(log n)` time.
