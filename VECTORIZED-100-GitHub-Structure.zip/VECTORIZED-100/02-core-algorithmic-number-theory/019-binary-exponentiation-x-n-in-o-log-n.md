# 19. Binary Exponentiation — `x^n` in `O(log n)`

Fast power calculation using repeated squaring.
