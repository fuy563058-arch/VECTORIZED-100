# 20. Modular Exponentiation — `(x^n) mod m`

Efficiently calculates large powers under a modulus.
