# 23. Extended Euclidean Algorithm

Finds coefficients `x` and `y` such that:

`ax + by = gcd(a, b)`
