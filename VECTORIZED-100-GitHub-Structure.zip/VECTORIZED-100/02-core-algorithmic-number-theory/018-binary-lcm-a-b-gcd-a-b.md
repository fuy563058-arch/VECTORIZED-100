# 18. Binary LCM — `(a × b) / gcd(a, b)`

Calculates the least common multiple using the GCD.
