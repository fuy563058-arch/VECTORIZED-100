# Core Algorithmic & Number Theory

Methods **16–30**.

- [16. Gauss Series Sum — `N(N + 1) / 2`](./016-gauss-series-sum-n-n-1-2.md)
- [17. Euclidean GCD — `gcd(a, b)`](./017-euclidean-gcd-gcd-a-b.md)
- [18. Binary LCM — `(a × b) / gcd(a, b)`](./018-binary-lcm-a-b-gcd-a-b.md)
- [19. Binary Exponentiation — `x^n` in `O(log n)`](./019-binary-exponentiation-x-n-in-o-log-n.md)
- [20. Modular Exponentiation — `(x^n) mod m`](./020-modular-exponentiation-x-n-mod-m.md)
- [21. Sieve of Eratosthenes](./021-sieve-of-eratosthenes.md)
- [22. Segmented Sieve](./022-segmented-sieve.md)
- [23. Extended Euclidean Algorithm](./023-extended-euclidean-algorithm.md)
- [24. Modular Multiplicative Inverse](./024-modular-multiplicative-inverse.md)
- [25. Chinese Remainder Theorem](./025-chinese-remainder-theorem.md)
- [26. Fast Fibonacci — Matrix Exponentiation](./026-fast-fibonacci-matrix-exponentiation.md)
- [27. Pascal's Triangle — `nCr`](./027-pascal-s-triangle-ncr.md)
- [28. Lucas' Theorem](./028-lucas-theorem.md)
- [29. Miller-Rabin Primality Test](./029-miller-rabin-primality-test.md)
- [30. Karatsuba Multiplication](./030-karatsuba-multiplication.md)
