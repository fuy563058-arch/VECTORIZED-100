# 30. Karatsuba Multiplication

Multiplies large integers in approximately `O(n^1.58)` time.

---

## Category 3: Array & Matrix Operations

*Methods 31–45 — High-performance array processing and linear algebra techniques.*
