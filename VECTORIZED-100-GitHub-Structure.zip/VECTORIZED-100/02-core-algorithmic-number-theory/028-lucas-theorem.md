# 28. Lucas' Theorem

Calculates `nCr mod p` efficiently for large `n` and `r` when `p` is prime.
