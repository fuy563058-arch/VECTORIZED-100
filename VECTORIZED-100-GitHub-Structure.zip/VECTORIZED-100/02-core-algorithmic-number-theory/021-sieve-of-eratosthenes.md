# 21. Sieve of Eratosthenes

Generates all prime numbers up to `N` in `O(N log log N)` time.
