# 27. Pascal's Triangle — `nCr`

Uses Pascal's Triangle and dynamic programming to calculate combinations.
