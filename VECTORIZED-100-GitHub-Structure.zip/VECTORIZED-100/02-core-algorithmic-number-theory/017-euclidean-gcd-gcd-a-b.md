# 17. Euclidean GCD — `gcd(a, b)`

Efficient logarithmic algorithm for finding the greatest common divisor.
