# 25. Chinese Remainder Theorem

Solves systems of simultaneous congruences.
