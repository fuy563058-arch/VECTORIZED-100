# 24. Modular Multiplicative Inverse

Solves:

`a × x ≡ 1 (mod m)`
