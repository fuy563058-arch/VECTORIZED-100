# 16. Gauss Series Sum — `N(N + 1) / 2`

`O(1)` summation of the sequence `1 ... N`.
