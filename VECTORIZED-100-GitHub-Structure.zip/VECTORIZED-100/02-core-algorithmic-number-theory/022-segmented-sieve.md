# 22. Segmented Sieve

Memory-efficient prime generation for large ranges.
