# 33. Difference Array

Performs range updates efficiently, often in `O(1)` per update.
