# 40. Matrix Inversion — Gauss-Jordan

Finds a matrix inverse through elementary row operations.
