# 43. Sparse Matrix-Vector Multiplication — CSR

Uses Compressed Sparse Row (`CSR`) representation to avoid unnecessary operations on zero values.
