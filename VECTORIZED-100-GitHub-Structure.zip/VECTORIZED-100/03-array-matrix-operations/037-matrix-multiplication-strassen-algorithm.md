# 37. Matrix Multiplication — Strassen Algorithm

Performs matrix multiplication in sub-cubic time.
