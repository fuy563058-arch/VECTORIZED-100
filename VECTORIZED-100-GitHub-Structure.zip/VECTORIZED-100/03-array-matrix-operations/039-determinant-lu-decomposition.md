# 39. Determinant — LU Decomposition

Computes a matrix determinant using LU decomposition, typically in `O(N^3)` time.
