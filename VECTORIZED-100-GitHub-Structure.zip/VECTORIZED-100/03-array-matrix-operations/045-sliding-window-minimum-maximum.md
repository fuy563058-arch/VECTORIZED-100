# 45. Sliding Window Minimum/Maximum

Uses a monotonic queue to answer sliding-window minimum or maximum queries in `O(N)`.

---

## Category 4: Geometry & Spatial Calculations

*Methods 46–60 — Mathematical techniques for game engines, physics, computer graphics, and mapping.*
