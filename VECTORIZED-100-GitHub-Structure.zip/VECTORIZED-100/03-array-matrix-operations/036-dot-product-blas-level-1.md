# 36. Dot Product — BLAS Level 1

Calculates the inner product of two vectors.
