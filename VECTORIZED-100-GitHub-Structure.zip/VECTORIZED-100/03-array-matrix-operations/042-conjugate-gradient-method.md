# 42. Conjugate Gradient Method

Efficiently solves certain large sparse linear systems.
