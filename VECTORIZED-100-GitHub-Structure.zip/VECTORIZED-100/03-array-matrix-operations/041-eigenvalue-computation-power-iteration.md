# 41. Eigenvalue Computation — Power Iteration

Iteratively estimates the dominant eigenvalue and corresponding eigenvector.
