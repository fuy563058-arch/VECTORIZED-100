# 38. Matrix Transpose — Cache-Oblivious

Uses blocking techniques to improve hardware cache locality.
