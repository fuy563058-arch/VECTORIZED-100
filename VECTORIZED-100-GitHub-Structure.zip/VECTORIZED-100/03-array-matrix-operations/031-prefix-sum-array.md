# 31. Prefix Sum Array

Preprocesses an array in `O(N)` to answer range-sum queries in `O(1)`.
