# 32. 2D Prefix Sum — Summed-Area Table

Enables `O(1)` sub-grid or rectangle sum queries after preprocessing.
