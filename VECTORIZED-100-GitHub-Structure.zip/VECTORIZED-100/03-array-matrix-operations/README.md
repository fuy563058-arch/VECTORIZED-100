# Array & Matrix Operations

Methods **31–45**.

- [31. Prefix Sum Array](./031-prefix-sum-array.md)
- [32. 2D Prefix Sum — Summed-Area Table](./032-2d-prefix-sum-summed-area-table.md)
- [33. Difference Array](./033-difference-array.md)
- [34. Kadane's Algorithm](./034-kadane-s-algorithm.md)
- [35. Matrix Addition Vectorization](./035-matrix-addition-vectorization.md)
- [36. Dot Product — BLAS Level 1](./036-dot-product-blas-level-1.md)
- [37. Matrix Multiplication — Strassen Algorithm](./037-matrix-multiplication-strassen-algorithm.md)
- [38. Matrix Transpose — Cache-Oblivious](./038-matrix-transpose-cache-oblivious.md)
- [39. Determinant — LU Decomposition](./039-determinant-lu-decomposition.md)
- [40. Matrix Inversion — Gauss-Jordan](./040-matrix-inversion-gauss-jordan.md)
- [41. Eigenvalue Computation — Power Iteration](./041-eigenvalue-computation-power-iteration.md)
- [42. Conjugate Gradient Method](./042-conjugate-gradient-method.md)
- [43. Sparse Matrix-Vector Multiplication — CSR](./043-sparse-matrix-vector-multiplication-csr.md)
- [44. Convolution via FFT](./044-convolution-via-fft.md)
- [45. Sliding Window Minimum/Maximum](./045-sliding-window-minimum-maximum.md)
