# 34. Kadane's Algorithm

Finds the maximum subarray sum in `O(N)` time.
