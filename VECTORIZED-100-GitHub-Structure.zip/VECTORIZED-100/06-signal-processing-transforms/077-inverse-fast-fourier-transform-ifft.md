# 77. Inverse Fast Fourier Transform — IFFT

Converts frequency-domain data back into the time domain.
