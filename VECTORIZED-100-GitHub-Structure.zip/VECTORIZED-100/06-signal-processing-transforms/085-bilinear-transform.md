# 85. Bilinear Transform

Converts analog filter designs into digital IIR filter implementations.

---

## Category 7: Optimization, Machine Learning & Graphs

*Methods 86–100 — Algorithms for optimization, artificial intelligence, pathfinding, compression, and network analysis.*
