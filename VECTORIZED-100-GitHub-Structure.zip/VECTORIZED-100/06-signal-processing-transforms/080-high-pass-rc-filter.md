# 80. High-Pass RC Filter

Reduces low-frequency components and emphasizes rapid changes.
