# Signal Processing & Transforms

Methods **76–85**.

- [76. Cooley-Tukey Fast Fourier Transform — FFT](./076-cooley-tukey-fast-fourier-transform-fft.md)
- [77. Inverse Fast Fourier Transform — IFFT](./077-inverse-fast-fourier-transform-ifft.md)
- [78. Discrete Cosine Transform — DCT](./078-discrete-cosine-transform-dct.md)
- [79. Low-Pass RC Filter](./079-low-pass-rc-filter.md)
- [80. High-Pass RC Filter](./080-high-pass-rc-filter.md)
- [81. Kalman Filter](./081-kalman-filter.md)
- [82. Windowing Functions — Hann / Hamming](./082-windowing-functions-hann-hamming.md)
- [83. Savitzky-Golay Filter](./083-savitzky-golay-filter.md)
- [84. Auto-Correlation Function](./084-auto-correlation-function.md)
- [85. Bilinear Transform](./085-bilinear-transform.md)
