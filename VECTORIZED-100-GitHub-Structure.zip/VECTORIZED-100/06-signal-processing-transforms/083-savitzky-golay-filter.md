# 83. Savitzky-Golay Filter

Smooths noisy data while preserving important features such as trends and peaks.
