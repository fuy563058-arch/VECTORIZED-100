# 78. Discrete Cosine Transform — DCT

Transforms data into cosine frequency components and is widely used in compression techniques.
