# 79. Low-Pass RC Filter

Reduces high-frequency components and can be used for basic signal smoothing.
