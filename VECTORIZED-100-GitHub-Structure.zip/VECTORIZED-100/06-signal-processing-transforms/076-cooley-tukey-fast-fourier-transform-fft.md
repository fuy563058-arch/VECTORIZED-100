# 76. Cooley-Tukey Fast Fourier Transform — FFT

Transforms a signal from the time domain into the frequency domain in `O(N log N)` time.
