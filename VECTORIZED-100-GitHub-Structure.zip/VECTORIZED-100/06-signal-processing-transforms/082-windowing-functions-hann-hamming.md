# 82. Windowing Functions — Hann / Hamming

Reduces spectral leakage before performing an FFT.
