# 84. Auto-Correlation Function

Measures similarity between a signal and a delayed version of itself, helping detect repeating patterns.
