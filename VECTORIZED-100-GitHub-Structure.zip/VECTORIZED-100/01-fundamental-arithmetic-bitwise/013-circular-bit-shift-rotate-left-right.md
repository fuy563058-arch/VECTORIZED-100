# 13. Circular Bit Shift — Rotate Left/Right

Rotates bits around an integer, commonly used in cryptography and hashing.
