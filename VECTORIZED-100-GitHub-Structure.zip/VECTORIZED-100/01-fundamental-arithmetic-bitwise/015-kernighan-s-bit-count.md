# 15. Kernighan's Bit Count

Counts set bits using a loop proportional to the number of set bits.

---

## Category 2: Core Algorithmic & Number Theory

*Methods 16–30 — Techniques that reduce computational complexity to `O(log N)` or `O(1)` where applicable.*
