# 14. Fast Ceiling Division — `(a + b - 1) / b`

Integer ceiling division without floating-point conversion.
