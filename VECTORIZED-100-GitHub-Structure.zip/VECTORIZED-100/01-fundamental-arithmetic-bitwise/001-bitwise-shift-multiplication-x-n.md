# 1. Bitwise Shift Multiplication — `x << n`

Fast multiplication by powers of `2`.
