# 6. Lowest Set Bit — `x & -x`

Isolates the lowest non-zero bit, useful in tree structures and bit manipulation.
