# Fundamental Arithmetic & Bitwise

Methods **1–15**.

- [1. Bitwise Shift Multiplication — `x << n`](./001-bitwise-shift-multiplication-x-n.md)
- [2. Bitwise Shift Division — `x >> n`](./002-bitwise-shift-division-x-n.md)
- [3. Parity Check — `x & 1`](./003-parity-check-x-1.md)
- [4. Fast XOR Swap](./004-fast-xor-swap.md)
- [5. Power of Two Check — `(x & (x - 1)) == 0`](./005-power-of-two-check-x-x-1-0.md)
- [6. Lowest Set Bit — `x & -x`](./006-lowest-set-bit-x-x.md)
- [7. Population Count — `popcount`](./007-population-count-popcount.md)
- [8. Integer Square Root — Newton's Method](./008-integer-square-root-newton-s-method.md)
- [9. Fast Inverse Square Root — `1 / sqrt(x)`](./009-fast-inverse-square-root-1-sqrt-x.md)
- [10. Absolute Value — Bitwise](./010-absolute-value-bitwise.md)
- [11. Signum Function](./011-signum-function.md)
- [12. Saturated Addition](./012-saturated-addition.md)
- [13. Circular Bit Shift — Rotate Left/Right](./013-circular-bit-shift-rotate-left-right.md)
- [14. Fast Ceiling Division — `(a + b - 1) / b`](./014-fast-ceiling-division-a-b-1-b.md)
- [15. Kernighan's Bit Count](./015-kernighan-s-bit-count.md)
