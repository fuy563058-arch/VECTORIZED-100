# 5. Power of Two Check — `(x & (x - 1)) == 0`

`O(1)` check for whether an integer is a power of `2`.
