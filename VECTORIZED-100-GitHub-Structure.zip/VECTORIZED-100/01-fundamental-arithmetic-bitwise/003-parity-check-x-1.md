# 3. Parity Check — `x & 1`

`O(1)` even/odd check without using the modulo operator.
