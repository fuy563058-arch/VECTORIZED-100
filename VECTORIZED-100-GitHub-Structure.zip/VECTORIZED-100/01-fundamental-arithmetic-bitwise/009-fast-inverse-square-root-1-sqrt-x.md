# 9. Fast Inverse Square Root — `1 / sqrt(x)`

Fast approximation used historically for vector normalization.
