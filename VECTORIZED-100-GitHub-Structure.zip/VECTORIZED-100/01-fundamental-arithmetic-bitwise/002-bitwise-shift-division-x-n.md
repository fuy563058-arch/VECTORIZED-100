# 2. Bitwise Shift Division — `x >> n`

Fast integer division by powers of `2`.
