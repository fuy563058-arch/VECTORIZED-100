# 12. Saturated Addition

Clamps the result to prevent integer overflow.
