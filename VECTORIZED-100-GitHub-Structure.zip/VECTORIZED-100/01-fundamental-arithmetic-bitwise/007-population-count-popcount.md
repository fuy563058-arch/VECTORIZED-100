# 7. Population Count — `popcount`

Counts the total number of set bits in an integer.
