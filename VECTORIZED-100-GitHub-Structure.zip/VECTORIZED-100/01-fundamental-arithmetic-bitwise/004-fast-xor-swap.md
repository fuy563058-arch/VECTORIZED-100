# 4. Fast XOR Swap

Swaps two variables without a temporary variable.
