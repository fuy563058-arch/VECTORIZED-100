# 11. Signum Function

Returns `-1`, `0`, or `1` based on the sign of a value.
