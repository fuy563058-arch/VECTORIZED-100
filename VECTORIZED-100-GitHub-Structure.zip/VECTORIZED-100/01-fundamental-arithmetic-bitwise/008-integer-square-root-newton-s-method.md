# 8. Integer Square Root — Newton's Method

Fast square-root approximation without relying on floating-point calculations.
