# 10. Absolute Value — Bitwise

Branchless calculation of the absolute value of an integer.
