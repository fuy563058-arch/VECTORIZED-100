# 90. Cross-Entropy Loss

Measures the difference between predicted probabilities and the target distribution.
