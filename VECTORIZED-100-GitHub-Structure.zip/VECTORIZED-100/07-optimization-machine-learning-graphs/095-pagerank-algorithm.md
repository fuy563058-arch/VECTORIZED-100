# 95. PageRank Algorithm

Uses iterative calculations to estimate the importance of nodes in a network.
