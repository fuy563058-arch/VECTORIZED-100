# 97. K-Means Distance Update

Calculates distances between data points and cluster centroids and updates cluster assignments/centroids.
