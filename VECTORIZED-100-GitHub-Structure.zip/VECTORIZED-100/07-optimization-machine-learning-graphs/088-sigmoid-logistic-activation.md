# 88. Sigmoid / Logistic Activation

Maps real-valued inputs into the range `(0, 1)`.
