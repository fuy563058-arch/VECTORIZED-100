# 100. L2 Regularization — Ridge

```text
λ ||w||₂²
```

Adds a penalty based on the squared magnitude of model weights to help reduce overfitting.

---

# Summary

These **100 calculation methods** cover a wide range of computer science and software development topics:

* **Bit manipulation**
* **Arithmetic**
* **Number theory**
* **Algorithms**
* **Arrays**
* **Matrices**
* **Geometry**
* **Statistics**
* **Probability**
* **Financial mathematics**
* **Signal processing**
* **Machine learning**
* **Optimization**
* **Graph algorithms**
* **Data compression**

> **Goal:** Build a strong calculation toolkit for solving programming and algorithmic problems efficiently.
