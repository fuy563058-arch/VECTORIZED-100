# 98. Gradient Boosting Step

Calculates residual errors that are used to train subsequent decision trees.
