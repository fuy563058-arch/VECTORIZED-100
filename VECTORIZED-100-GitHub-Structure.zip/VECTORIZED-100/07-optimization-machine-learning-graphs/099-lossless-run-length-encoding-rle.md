# 99. Lossless Run-Length Encoding — RLE

Compresses repeated consecutive values by representing them as value-count pairs.
