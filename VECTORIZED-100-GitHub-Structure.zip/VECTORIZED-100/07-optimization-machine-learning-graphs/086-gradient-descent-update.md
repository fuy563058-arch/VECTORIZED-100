# 86. Gradient Descent Update

```text
θ = θ - α∇J(θ)
```

Updates model parameters to minimize a loss function.
