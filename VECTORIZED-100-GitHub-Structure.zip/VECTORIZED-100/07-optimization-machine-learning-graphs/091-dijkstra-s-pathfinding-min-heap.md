# 91. Dijkstra's Pathfinding — Min-Heap

Finds shortest paths from a source node when edge weights are non-negative.

Typical complexity with a binary heap:

```text
O((V + E) log V)
```
