# 87. Softmax Function

Converts raw model scores into a probability distribution.
