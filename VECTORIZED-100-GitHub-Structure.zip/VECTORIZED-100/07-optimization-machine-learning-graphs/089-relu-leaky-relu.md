# 89. ReLU / Leaky ReLU

```text
ReLU(x) = max(0, x)
```

Simple neural-network activation functions.
