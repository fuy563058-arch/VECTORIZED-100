# 94. Floyd-Warshall Algorithm

Computes shortest paths between every pair of vertices in `O(V^3)` time.
