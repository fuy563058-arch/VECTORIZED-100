# Optimization, Machine Learning & Graphs

Methods **86–100**.

- [86. Gradient Descent Update](./086-gradient-descent-update.md)
- [87. Softmax Function](./087-softmax-function.md)
- [88. Sigmoid / Logistic Activation](./088-sigmoid-logistic-activation.md)
- [89. ReLU / Leaky ReLU](./089-relu-leaky-relu.md)
- [90. Cross-Entropy Loss](./090-cross-entropy-loss.md)
- [91. Dijkstra's Pathfinding — Min-Heap](./091-dijkstra-s-pathfinding-min-heap.md)
- [92. A* Search — Heuristic Distance](./092-a-search-heuristic-distance.md)
- [93. Bellman-Ford Algorithm](./093-bellman-ford-algorithm.md)
- [94. Floyd-Warshall Algorithm](./094-floyd-warshall-algorithm.md)
- [95. PageRank Algorithm](./095-pagerank-algorithm.md)
- [96. Cosine Similarity](./096-cosine-similarity.md)
- [97. K-Means Distance Update](./097-k-means-distance-update.md)
- [98. Gradient Boosting Step](./098-gradient-boosting-step.md)
- [99. Lossless Run-Length Encoding — RLE](./099-lossless-run-length-encoding-rle.md)
- [100. L2 Regularization — Ridge](./100-l2-regularization-ridge.md)
