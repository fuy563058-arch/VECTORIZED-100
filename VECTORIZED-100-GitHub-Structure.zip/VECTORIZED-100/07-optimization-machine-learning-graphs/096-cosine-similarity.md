# 96. Cosine Similarity

Measures similarity between high-dimensional vectors using the angle between them.
