# 92. A* Search — Heuristic Distance

An informed shortest-path algorithm that combines actual cost with a heuristic estimate.
