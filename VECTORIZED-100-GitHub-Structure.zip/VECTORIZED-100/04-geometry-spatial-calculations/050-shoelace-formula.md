# 50. Shoelace Formula

Calculates the area of a polygon in `O(N)` time.
