# 53. Barycentric Coordinates

Represents a point relative to a triangle and enables interpolation across 2D/3D triangles.
