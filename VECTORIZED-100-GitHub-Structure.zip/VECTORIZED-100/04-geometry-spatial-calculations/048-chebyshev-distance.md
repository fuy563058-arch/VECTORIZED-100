# 48. Chebyshev Distance

```text
max(|Δx|, |Δy|)
```

Distance metric commonly associated with chessboard movement.
