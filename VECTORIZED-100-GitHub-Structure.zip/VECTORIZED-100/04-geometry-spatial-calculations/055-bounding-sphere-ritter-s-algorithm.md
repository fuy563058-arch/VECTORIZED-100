# 55. Bounding Sphere — Ritter's Algorithm

Fast linear-time approximation for creating a bounding sphere around a collection of points.
