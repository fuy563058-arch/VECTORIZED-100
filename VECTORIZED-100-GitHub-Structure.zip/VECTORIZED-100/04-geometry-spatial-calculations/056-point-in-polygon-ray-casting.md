# 56. Point-in-Polygon — Ray Casting

Determines whether a point lies inside or outside a polygon.
