# 54. Quaternion Multiplication

Combines 3D rotations while avoiding the gimbal-lock problems associated with Euler angles.
