# Geometry & Spatial Calculations

Methods **46–60**.

- [46. Euclidean Distance — `2D / 3D`](./046-euclidean-distance-2d-3d.md)
- [47. Manhattan Distance](./047-manhattan-distance.md)
- [48. Chebyshev Distance](./048-chebyshev-distance.md)
- [49. Haversine Formula](./049-haversine-formula.md)
- [50. Shoelace Formula](./050-shoelace-formula.md)
- [51. 2D Cross Product — Orientation Test](./051-2d-cross-product-orientation-test.md)
- [52. Ray-AABB Intersection — Slab Method](./052-ray-aabb-intersection-slab-method.md)
- [53. Barycentric Coordinates](./053-barycentric-coordinates.md)
- [54. Quaternion Multiplication](./054-quaternion-multiplication.md)
- [55. Bounding Sphere — Ritter's Algorithm](./055-bounding-sphere-ritter-s-algorithm.md)
- [56. Point-in-Polygon — Ray Casting](./056-point-in-polygon-ray-casting.md)
- [57. Linear Interpolation — `Lerp`](./057-linear-interpolation-lerp.md)
- [58. Spherical Linear Interpolation — `Slerp`](./058-spherical-linear-interpolation-slerp.md)
- [59. Convex Hull — Graham Scan](./059-convex-hull-graham-scan.md)
- [60. Voronoi Tessellation — Fortune's Algorithm](./060-voronoi-tessellation-fortune-s-algorithm.md)
