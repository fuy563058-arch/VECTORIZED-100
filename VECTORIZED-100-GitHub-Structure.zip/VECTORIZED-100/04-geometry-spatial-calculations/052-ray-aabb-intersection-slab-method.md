# 52. Ray-AABB Intersection — Slab Method

Efficient ray intersection test for axis-aligned bounding boxes.
