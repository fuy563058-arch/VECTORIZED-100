# 49. Haversine Formula

Calculates great-circle distance between two coordinates on a sphere.

Useful for GPS and geographic calculations.
