# 46. Euclidean Distance — `2D / 3D`

```text
2D: √(Δx² + Δy²)

3D: √(Δx² + Δy² + Δz²)
```

Calculates the straight-line distance between points.
