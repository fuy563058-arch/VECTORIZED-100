# 60. Voronoi Tessellation — Fortune's Algorithm

Constructs a Voronoi diagram in `O(N log N)` time.

---

## Category 5: Statistics, Probability & Financial Math

*Methods 61–75 — Statistical calculations, probability techniques, time-series modeling, and financial mathematics.*
