# 47. Manhattan Distance

```text
|Δx| + |Δy|
```

Grid-based distance where movement is restricted to horizontal and vertical directions.
