# 58. Spherical Linear Interpolation — `Slerp`

Smoothly interpolates between two rotations represented on a sphere.
