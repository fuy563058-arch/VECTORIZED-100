# 51. 2D Cross Product — Orientation Test

Determines the orientation of three points and whether a turn is clockwise or counterclockwise.
