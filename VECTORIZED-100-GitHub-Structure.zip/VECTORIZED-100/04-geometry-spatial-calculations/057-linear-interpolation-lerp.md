# 57. Linear Interpolation — `Lerp`

```text
a + t(b - a)
```

Smoothly interpolates between two values.
