# 59. Convex Hull — Graham Scan

Finds the smallest convex boundary containing a set of points in `O(N log N)` time.
