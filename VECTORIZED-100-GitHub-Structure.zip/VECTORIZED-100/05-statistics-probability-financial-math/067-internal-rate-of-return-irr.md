# 67. Internal Rate of Return — IRR

Iteratively calculates the discount rate at which an investment's NPV becomes zero.
