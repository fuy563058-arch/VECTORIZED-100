# Statistics, Probability & Financial Math

Methods **61–75**.

- [61. Welford's Algorithm](./061-welford-s-algorithm.md)
- [62. Rolling Moving Average — SMA](./062-rolling-moving-average-sma.md)
- [63. Exponential Moving Average — EMA](./063-exponential-moving-average-ema.md)
- [64. Percentile / Median — Quickselect](./064-percentile-median-quickselect.md)
- [65. Compound Interest Formula](./065-compound-interest-formula.md)
- [66. Net Present Value — NPV](./066-net-present-value-npv.md)
- [67. Internal Rate of Return — IRR](./067-internal-rate-of-return-irr.md)
- [68. Pearson Correlation Coefficient](./068-pearson-correlation-coefficient.md)
- [69. Covariance Matrix](./069-covariance-matrix.md)
- [70. Monte Carlo Simulation](./070-monte-carlo-simulation.md)
- [71. Box-Muller Transform](./071-box-muller-transform.md)
- [72. Reservoir Sampling](./072-reservoir-sampling.md)
- [73. Black-Scholes Model](./073-black-scholes-model.md)
- [74. Z-Score Normalization](./074-z-score-normalization.md)
- [75. Min-Max Feature Scaling](./075-min-max-feature-scaling.md)
