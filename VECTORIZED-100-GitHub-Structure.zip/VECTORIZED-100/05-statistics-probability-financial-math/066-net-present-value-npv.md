# 66. Net Present Value — NPV

Calculates the present value of future cash flows using a discount rate.
