# 68. Pearson Correlation Coefficient

Measures the strength and direction of a linear relationship between two datasets.
