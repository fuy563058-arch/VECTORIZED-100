# 74. Z-Score Normalization

```text
z = (x - μ) / σ
```

Rescales data so that the transformed distribution has mean `0` and standard deviation `1`.
