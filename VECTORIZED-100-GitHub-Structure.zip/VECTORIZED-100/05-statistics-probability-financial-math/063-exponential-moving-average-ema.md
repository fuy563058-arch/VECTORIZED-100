# 63. Exponential Moving Average — EMA

Applies greater weight to recent values for time-series smoothing.
