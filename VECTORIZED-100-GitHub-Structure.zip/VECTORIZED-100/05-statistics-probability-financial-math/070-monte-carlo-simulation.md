# 70. Monte Carlo Simulation

Uses repeated random sampling to approximate probabilities and solve numerical problems.
