# 75. Min-Max Feature Scaling

```text
x' = (x - min) / (max - min)
```

Rescales values into the `[0, 1]` range.

---

## Category 6: Signal Processing & Transforms

*Methods 76–85 — Digital signal processing, filtering, and frequency-domain calculations.*
