# 61. Welford's Algorithm

Calculates running mean and variance in a numerically stable single pass.
