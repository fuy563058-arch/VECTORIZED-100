# 65. Compound Interest Formula

```text
A = P(1 + r/n)^(nt)
```

Calculates accumulated value with compound interest.
