# 62. Rolling Moving Average — SMA

Maintains a moving average with `O(1)` updates for streaming data.
