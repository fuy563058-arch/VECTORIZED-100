# 69. Covariance Matrix

Represents the variance and covariance relationships between multiple variables.
