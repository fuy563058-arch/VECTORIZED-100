# 72. Reservoir Sampling

Selects `K` random items from a stream without knowing the stream's total size in advance.
