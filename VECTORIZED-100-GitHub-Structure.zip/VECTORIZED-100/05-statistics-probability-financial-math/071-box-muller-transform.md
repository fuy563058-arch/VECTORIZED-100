# 71. Box-Muller Transform

Transforms uniformly distributed random values into normally distributed values.
