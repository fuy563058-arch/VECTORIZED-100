# 73. Black-Scholes Model

Mathematical model used for theoretical pricing of certain financial options.
